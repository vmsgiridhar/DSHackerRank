sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/ODataModel"
], function (Controller,JSONModel, ODataModel) {
	"use strict";

	return Controller.extend("integMonitorDashboard.integMonitorDashboard.controller.integMonitor", {
		onInit : function(){
			this.handleReadCall();
			this.getOwnerComponent().getRouter().getRoute('RouteintegMonitor').attachMatched(this.onRouteMatched,this);
		},
		onRouteMatched : function(oEvent){
			console.log('Hello I am route Mathced');
		},
		handleReadCall : function(){
			var that = this;
		var odataModel = new ODataModel('/sap/opu/odata/sap/ZPLANCAL_SRV/');
		var parameters = {
			success: function(response){
				that.getOwnerComponent().getModel('systemStatusModel').setData(response);
			},
			error : function(error){}
		};
		odataModel.read('systemStatusSet', parameters)
			
		}

	});
});